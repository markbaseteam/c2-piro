- Los diagramas de las sales fundidas es:
![[Pasted image 20230719180749.png]]
- El ánodo es $${LiCl(l) = Li^+ + Cl^-}$$
	- Luego, el cátodo es:
$${2Cl^- = Cl_2(g) + 2e^-}$$
- Sal fundida