- Esto va luego de la molienda bajo 100 mallas y se le agrega agua, para hacer la lixiviación con la siguiente fórmula:
$${Li_2O + 3H_2O = 2LiOH \cdot H_2O}$$
- solamente se debe de lixiviar con el agua, no se le agrega ningún otro agente lixiviante como el ácido sulfúrico o el O2
	- Se forma el LiOH x H2O que es el producto de la lixivación del Li2O