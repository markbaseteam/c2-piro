- Tienes la reacción de:
$${2LiCl + Na_2CO_3 = Li_2CO_3 + 2NaCl}$$
En esta parte del flowsheet se le aplica el Na2CO3 para precipitar más tarde al LiCl
![[Pasted image 20230719175106.png]]
- [[siguiente-etapa-espesamiento-de-carnalita]]
