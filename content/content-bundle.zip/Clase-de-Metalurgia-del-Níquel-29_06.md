- La próxima semana es la parte de la metalurgia de Molidbeno
- Y queda el apunte de las emisiones
- posibilidad de adelantar el C2 de Hidro
#### Aspectos generales del Níquel
- Presenta similitudes con otros metales nobles
- En la forma en la que es extraído el níquel
- Similitud con el cobre
- Al igual que el aluminio, el Ni es afín por el oxígeno, aunque el Al es más
- Presenta bajas velocidades de oxidación
- [[autopasivación]]
- Un eje de níquel, (Fe-Ni-S) por oxidación eliminando casi todo el Hierro puro, forma sulfuro
- [[Yacimientos-de-sulfuros-de-Níquel]]
- Los minerales sulfurados de níquel se concentran por flotación para obtener concentrados colectivos de níquel y otros metales
- Ni y Cr inducen inoxidables en acero
- aleaciones y superaleaciones
- recubrimientos-de-níquel
	- de ciertas piezas metálicas, para mejorar el aspecto y resistencia en condiciones ambientales, superficie más brillante
- cuchillos de la turbina de los aviones jet, 
- Principales-compañías-en-Statista
	- international nickel company, minerales en sudbury en ontario
	- ahora es Norisk nickel y Glencore 2°
- difícil de reciclar porque está en aleaciones
- las reservas-mineras
	- son los recursos que son factibles de explotar técnica y económicamente
	- lo que se va descubriendo
- Precio del níquel, ha subido por expectativa, se usa en batería, no tiene términos de acumulación ni generación de energía como el Litio
- [[Procesos-de-tratamiento-de-níquel]]

- [[Metalurgia-del-Moly-apuntes]]

### Ejercicio de Balance
- [[Preparación-para-C2-de-Piro-20_07]]