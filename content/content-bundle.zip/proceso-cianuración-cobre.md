- Al igual que el Au y la Ag, el cobre y los sulfuros de cobre forman con el ión cianato una serie de [[cupro-cupritiocinatos]]
![[Pasted image 20230718183300.png]]
- Normalmente la pirita no se disuelve o muy poco en la solución de cianuración, no así con la FeS que aumenta el consumo de cianuro
- Por lo general se descartan estas soluciones y no se recupera el cu disuelto
	- Pero, esto es un problema ambiental por el contenido de CN y de Cobre contenido
	- Desventaja de la baja disolución de la CuFeS2