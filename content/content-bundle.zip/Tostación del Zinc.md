- Los de lecho fluidizado, se usan para convertir concentrados de esfalerita ZnS en óxidos de Zinc
- Calcina se lixivia
- Va a EW 
- Un metal con azufre se lleva a cabo la tostación para formar un óxido
- Se libera SO2
- [[Sinterización de Zn y de Pb]]
- Necesita aire a diferencia de la descomposición térmica
- La mayoría del Zinc producido en el mundo, cerca del 70 % es por la tostación en una primera etapa de los concentrados de cinc a 900-1050°C con aire para remover el azufre como SO2 y generar una calcina oxidada de ZnO
	- Eso se puede lixiviar? SÍ, es distinto a la [[lixiviación-neutra-del-zinc]] ya que se tiene que lixiviar con ácido sulfúrico diluido y el electrolito se purifica en la etapa siguiente
	- Luego, se obtienen cátodos de zinc.
	- La marmatita es la mena que contiene Fe que luego al tostarla se oxida a Fe2O3 con ZnO, es decir, ferrita de Zinc. Quedaría como ZnO x Fe2O3 
	- [[residuos-del-proceso-tostación-de-zinc]]

escribe la reacción de la tostación de la es

La tostación de la esfalerita ZnS es un proceso en el cual se calienta el mineral a altas temperaturas en presencia de oxígeno para producir óxido de zinc (ZnO) y dióxido de azufre (SO2). La reacción química que ocurre durante la tostación es la siguiente:

2ZnS + 3O2 → 2ZnO + 2SO2

Durante la tostación, el mineral se calienta a una temperatura entre 900 y 1000 grados Celsius en un horno especializado. El oxígeno se introduce en el horno para oxidar el sulfuro presente en la esfalerita, lo que produce óxido de zinc y dióxido de azufre. El óxido de zinc producido puede ser utilizado posteriormente para producir zinc metálico o para otros fines industriales.

En resumen, la reacción de tostación de la esfalerita ZnS produce óxido de zinc y dióxido de azufre como productos principales.falerita ZnS



