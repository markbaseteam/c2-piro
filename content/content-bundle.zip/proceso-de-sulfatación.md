- La purificación de MoS2 con ácido sulfúrico concentrado al 96 % y en caliente, a 150-220°C, fue patentado en 1933 por Morgan en USA
	- Ensayado a mayor escala en 1971 sin éxito
		- problemas de operación, alto contenido residual de cobre y problemas de corrosión
	- No fue aplicado a escala industrial 

### Proceso hecho por la UdeC
- La UdeC estudió un proceso en escala de laboratorio en 1981 y entre 1983-85 desarrolló un circuito y reactor piloto apropiado que resolvió los problemas de operación y corrosión
	- Proceso evaluado para aplicación comercial por división chuquicamata y Anglo american
- Se basa en emplear H2SO4 96-98% pureza a presión atm y con 150-200 °C
	- remueve alrededor del 98 % de Cu, 60 % de Fe, 95 % de As, 95 % de P
- Las impurezas de cobre en la molibdenita, que son de la forma CuFeS2, CuS, Cu2S se van en su mayoría como CuSO4 y el azufre se va tanto como S^0 y como SO2
