![[Pasted image 20230719165506.png]]
- Ingresa el LiAl(SiO3)2 al reactor de calcinación a 800-900°C, entra caliza como CaO y combustible
	- La reacción es:
2LiAl(SiO3)2 + 4CaO = Li2O + 4CaSiO3 +Al2O3
$${2LiAl(SiO_3)_2 + 4CaO = Li_2O + 4CaSiO_3 + Al_2O_3}$$
- Luego, va a un enfriador de calcinas
- Ojo que no es cal! es caliza!
- [[La-lixiviación-del-Li2O]] 
	- La ruta es calcinación-lixiviación-espesamiento-filtración-secado y los cristales de Litio vienen de la salida de la lixiviación del Li2O