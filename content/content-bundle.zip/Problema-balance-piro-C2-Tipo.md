1. Se ha ideado un proceso de tostación de metal blanco en lecho fluidizado seguido de lixiviación ácida para posterior recuperación del cobre por SX-EW y de los metales nobles por fusión a metal doré. El proceso se muestra en la figura siguiente: 
![[Pasted image 20230719105310.png]]
- Si el metal blanco, con 72 % de Cu, es alimentado al tostador a razón de 100 TPH y se emplea un 10 % de aire respecto del necesario para oxidar: todo el S gaseoso a SO2, todo el Fe a Fe2O3 y luego a ferrita cúprica, y todo el Cobre a CuO (excepto aquel que reacciona con el Fe2O3 para formar ferrita cúprica). Considerando como base de cálculo 1 hora:
- a) Determine la composición y el flujo de las corrientes de salida (calcina y gases)
- b) La cantidad de ácido que se requiere para la etapa de lixiviación si esta se realiza con una razón de L/S : de 15/1 (L/kg) y un 15% de exceso de ácido
- c) La composición y caudal del PLS
- d) Una estimación de producción de cobre catódico y ácido en el proceso

#### Desarrollo del Problema:
- Tienes una mata de metal blanco, con ley de 72 % de Cu, compuesta por Cu2S y FeS, para 100 tph ya es fácil determinar la cantidad de Cu en la mata, mCu2S, mFeS tal y como se hace en meta del Cobre
- PM Cu2S: 159.14, PM FeS: 87.91
- mCu = 100 x 0.72 = 72 tph Cu
- mCu2S = 72 tph Cu x 159.14 /2x63.54 = 90.16
- mFeS = 100-90.16 = 9.84 tph FeS
- Todo el Cu a CuO: Cu2S + 2O2 = 2CuO + SO2, como en el soplado de Cobre
- [[calcular-O2-teórico-O2-exceso]], el kmol de O2 total es de 1246.39 kmol O2, entonces, con el requerimiento de Nitrógeno, esto es = 1246.39 kmol x 79/21 = 4688.84 kmol de N2 Total!
- Con esto, se forma 1133.08 kmol de CuO y 566.54 kmol de SO2 gas, por estequiometría
- Entonces me imagino que hay una fracción de CuO o de Cu2S que reacciona con hematita para formar ferrita cúprica
	- La reacción es de CuO+ Fe2O3
	- y la hematita proviene de la reacción de la pirrotita
- La reacción de la Fe2O3 es:
	- 2FeS + 7/2O2 = Fe2O3 + 2SO2, tenemos 9.84 tph de FeS / 87.91 g/mol = 111.93 kmol de FeS, requerimiento de O2 = 111.93 kmol de FeS x 7/2mol de O2 / 2 mol de FeS = 111.93 kmol de FeS x 7/4 = 195.88 O2 teórico + 195.88 x 0.1 = 215.47 kmol O2 total, (voy en la página 3)
		- Como se emplea aire, entonces, se puede calcular la cantidad de N2 que se necesita en kmol para la oxidación de la pirrotita, 810.57 kmol de N2, de 215.47 kmol de O2 total
		- Luego, de SO2 y de Fe2O3, de SO2 se forman 111.93 kmol de SO2, es lo mismo, por estequiometría
		- y en el caso del Fe2O3, 111.93 kmol de FeS x 1 mol de Fe2O3 / 2 mol de FeS = 55.96 kmol. 