- La carnalita de litio tiene la fórmula química de:
$${LiCl \cdot MgCl_2 \cdot 6H_2O}$$
- Esta carnalita de litio, más tarde, reacciona con el Na2CO3 proveniente de un autoclave que se le agrega agua y Na2CO3 para acondicionamiento