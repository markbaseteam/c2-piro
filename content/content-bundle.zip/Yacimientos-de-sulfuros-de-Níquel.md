- El níquel se encuentra tanto en forma de sulfuro como de óxidos
- los óxidos en zonas cálidos y tropilaes
- sulfuros en zonas frías, en Rusia y en el norte de Rusia con finlandia
- [[menas-de-níquel]]
- Principales en Sudbury, ontario canadá, norilsk al noreste de siberia en rusia y en pechega, en kola, también Rusia

##### Menas asociados a cobalto
- Nueva Caledonia, indonesia
- cerro matoso, colombia
- cerro maimón, república dominicana
- nicaro y moa bay en cuba