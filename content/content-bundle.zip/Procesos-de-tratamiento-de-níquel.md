- i) cuando tiene bajo contenido de cobre, no es algo que se recupera en el proceso, tiene 15-20 % ni, 1-2 % de cu, 0.5-2% de co, 45-50 % de fe, 20-25 % de S total
	- ii) cuando hay alto contenido de cu se recupera
		- parte de 5-10% de cu
- En estos dos casos, el proceso es de fundición del eje de Ni-Cu-Fe-S
- Níquel a partir de concentrados de bajo contenido de cobre, 7 % Ni, 41 % Fe, 0.25 % Cu, 0.1 % Co, 28 % S, [[tratamiento-de-concentrado-baja-ley-níquel]]

- en la conversión hay un problema, 
- Composiciones-típicas-de-metales-blanco-como-de-eje

- [[Afinidad-de-metales-con-oxígeno]]
- [[tratamiento-de-concentrados-sulfurados-Ni-y-Cu]]