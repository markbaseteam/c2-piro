- Elemento metálico blanco plateado
- Es blando y liviano
- Altamente electropositivo
- Alta conductividad eléctrica
- Facilidad de formar un ión univalente y fuerte carácter básico de su hidróxido
- Menor potencial estándar de reducción

#### Aplicación del Litio
- La aplicación más importante de las sales de litio en la tecnología de LIB es su uso en la producción de material para cátodos.
- [[formas-de-cátodos-de-litio]]
- [[lubricantes-y-grasas]]
- [[esmaltes-y-cerámicas]]

#### Minerales de Litio
- [[minerales-de-litio]]
- [[salmueras-de-litio]]

