- Tiene las impurezas como forma de óxido
- Cu2O cuprita 
- As2O5 pentóxido de arsénico
- SiO2
- Fe2O3 hematita
- Al2O3 alúmina
- P2O5 pentóxido de fosfato

- Si están en forma de sulfatos
- CaSO4
- PbSO4
- MgSO4
	- Ya que el azufre es un problema y el contenido virtual de S en la calcina debería ser menor al 0.1%

- Si están en forma de molibdatos
- CaMoO4
- PbMoO4
- CuMoO4
- FeMoO4