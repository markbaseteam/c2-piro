---
quickshare-date: 2023-07-17 12:31:40
quickshare-url: "https://noteshare.space/note/clk737xmg187001mwyj7702qb#03Zi0M4hSC5FkAiJKkka+8L5SGQBg7MUHrxnsd1nNb4"
---
### Metalurgia del Zinc
- Vimos la clase pasada en cómo se extrae el Plomo, [[Clase-de-Piro-25_05]]
- El proceso [[Imperial-smelting]]
	- Procesa concentrados con altos contenidos de otros elementos
- [[Tostación del Zinc]]
	- Está muy relacionado con la metalurgia del Plomo, puede estar como impureza o bien como elementos de valor el zinc
	- El sulfuro de zinc se convierte en 
	- Luego va a una etapa de [[lixiviación-neutra-del-zinc]]
		- [[EW-de-Zinc-luego-de-purificación]]
- Las [[menas-de-Zinc]]
- Zonas muertas, tipo de que se produce un embancamiento, tipo en los [[Modelos de celda]] de los equipos de flotación
- En el lecho se va mezclando y ocurren las reacciones de oxidación
- El lecho está bajo la sección cónica
- Recuperar parte del sólido...
- Serpentín al interior del lecho, para que haga algo con los gases
- Los gases van a un precipitador
- Los gases cuando están calientes, van a un sistema de una sola etapa
- [[Sistema-de-recuperación-de-calor-de-zinc]]
- [[La-mampostería-refractaria]]
- El tamaño de partículas es alrededor de 100 %- 100 mallas 
- En la ganga, sale el ZnO como sólido, Fe2O3 (hematita), y estas reaccionan entre sí, generando la ferrita de zinc, algo parecido como la Fayalita, ZnO x Fe2O3
	- ZnO + Fe2O3 = ZnO x Fe2O3
- [[Otras-impurezas-de-Plomo]]
- 10 g/L de ácido en la [[lixiviación-neutra-del-zinc]], mientras que el ácido recirculado es de 100 g/L
- En la práctica es una lixiviación ácida débil
- Recuperar incluso el Zinc contenido en la ZnO x Fe2O3
	- Esta se disuelve a altas temperaturas
	- Salen los metales nobles del residuo, la solución va a una nueva etapa [[precipitación-de-sulfato-de-hierro-con-jarosita]]
		- Luego el oro por ejemplo, sale con la cianuración

[[Listado-5-de-Piro]]
- [[Clase-de-Metalurgia-del-Níquel-29_06]]