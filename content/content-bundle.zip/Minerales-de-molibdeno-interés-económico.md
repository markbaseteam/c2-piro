- La molibdenita con 59.5 % de Mo, MoS2, PMMo / PM MoS2
	- La molibdenita es el sulfuro más común y abundante, junto con otros como el MoS3y el Mo2S3, y otros sulfuros no estequiométricos S_(1-x)
- Wulfenita, PbMoO3, asociada con Plomo, 27.3 % de Mo
- Molibdita, Fe2O3 x MoO3, con la hematita en su fórmula química
- Powelita Ca(MoW)O4
	- con W que es tungsteno o wolframio
	
 Solamente los 4 primeros son explotados a gran escala!, y el MoS2 representa el 95 % del Mo producido
 - Ilsemanita MoO2 x 4MoO3 
- Bilonesita MgMoO4 
- Paterita CoMoO4