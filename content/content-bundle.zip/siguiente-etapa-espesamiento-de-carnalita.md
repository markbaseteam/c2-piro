- La carnalita, que tiene fórmula química de LiCl x MgCl2 x 6H2O, se rompe y el MgCl2 x 6H2O termina espesando con el Na2CO3 agregado a la primera lixiviación
$${MgCl_2 + 6H_2O + Na_2CO_3 = MgCO_3 + NaCl + 6H_2O}$$
	- en teoría el agua entra y sale igual
- CaCl2 + Na2CO3 = CaCO3 + 2NaCl
- en el espesamiento entonces, precipita como MgCO3 y el CaCO3